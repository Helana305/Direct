from django.shortcuts import render
from django.http import HttpResponse
def learning_hub(request):
    return HttpResponse("hello world")
def home_page(request):
    return render(request,'home.html')
# Create your views here.
