from django.contrib import admin
from django.urls import path,include
from . import views
urlpatterns = [
    path('kite/',views.learning_hub,name='kite'),
    path('',views.home_page,name='index')
    
]
